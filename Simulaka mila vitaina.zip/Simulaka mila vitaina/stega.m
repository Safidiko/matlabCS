function [im_stego,IT] = stega(imagePorteuse,image)
    [LL,LH,HL,HH] = dwt2(imagePorteuse,'haar');
    [m,n] = size(imagePorteuse);

    % on suppose que image = [m/4,n]
    D1 = mod(image,10);
    D2 = floor(image/10);

    D1 = reshape(D1,m/2,n/2);
    D2 = reshape(D2,m/2,n/2);
    IT = zeros(m/2,n/2);

    MV = median(LL,'all');
    for ii = 1:m/2
        for jj = 1:n/2
            if LL(ii,jj) >= MV
                IT(ii, jj) = 1;
                LH(ii, jj) = D1(ii, jj);
                HL(ii, jj) = D2(ii, jj);
            else
                IT(ii, jj) = 0;
                LH(ii, jj) = D2(ii, jj);
                HL(ii, jj) = D1(ii, jj);
            end
        end
    end
    im_stego = idwt2(LL,LH,HL,HH,'haar');
end         
                
         