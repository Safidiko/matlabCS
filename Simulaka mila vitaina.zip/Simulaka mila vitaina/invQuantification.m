function source = invQuantification(imageQuantifie,max,min)
    source = (max-min)/255 *(imageQuantifie)+ min;
end