function image = inversedwt(imagedwt)
    [a,~,~] = size(imagedwt)
    ww= DWT(a);
    image = full(ww'*sparse(imagedwt(:,:))*ww);
end