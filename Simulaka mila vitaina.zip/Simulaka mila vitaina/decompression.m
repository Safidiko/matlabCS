function im_reconstruct = decompression(matsensing,im_compressed,ratio)
[ligne,col,~]=size(im_compressed);
    ligne = round(ligne/ratio);
    im_reconstruct =zeros(ligne,col);
    for ii = 1:col
        im_reconstruct(:,ii) = cs_omp(im_compressed(:,ii),matsensing);
    end
        
end