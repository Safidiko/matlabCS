function q = initialParameters(P,S)
%% Les paramètres d'entrée et de sortie
% q          : output  [x_0,y_0,g_0,r]
% bitsMatrix : 256 bits with 32 
% S          : vecteur colonne [x_0',y_0',g_0',r']
 sommeTotale =0;
for jj =1:32
    sommeTotale = sommeTotale +binaryVectorToDecimal(P(jj,:))*2^(8*(jj-1))/2^256;
end
%% Matrice q[x_0, y_0,r,z_0]
q=zeros(4,1);
for ii = 1:4
    terme_1 = (binaryVectorToDecimal(P(4*ii-2,:)) + (4*ii-2))/( binaryVectorToDecimal(P(3*ii,:)) + 3*ii);
    terme_2 = (binaryVectorToDecimal(P(5*ii-3,:)) + (5*ii - 3))/( binaryVectorToDecimal(P(4*ii,:)) + 4*ii);
    q(ii,:) = mod((S(ii,:)+(terme_1 + terme_2)*sommeTotale),1);
end
end