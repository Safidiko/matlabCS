function image = OMP_2D(img_compressed,phi,ligne,colonne)
image = zeros(ligne,colonne);
for i=1:colonne
  image(:,i) = cs_omp(img_compressed(:,i),phi);
end