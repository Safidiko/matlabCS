function imdwt=ondelette(image)
    [a,~]=size(image);
    ww = DWT(a);
    imdwt = ww*image*ww';
end