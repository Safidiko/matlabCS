function image = stegaExtract(imstega,imhote,dim,coeff)
    [cA_1,~,~,~] =dwt2(imstega,'haar');
    [cA_2,~,~,~] =dwt2(imhote,'haar');
    ligne = dim(1);
    col   = dim(2);
    image = (cA_1(1:ligne,1:col,1)-cA_2(1:ligne,1:col,1))./coeff;
end