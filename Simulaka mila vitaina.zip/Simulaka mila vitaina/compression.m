function compressed = compression(Phi,imageDWT)
    compressed = Phi*imageDWT;
end