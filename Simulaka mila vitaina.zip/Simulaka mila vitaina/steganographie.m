%% STEGA TEST

%% prise de taille:
imhote = double(imread('imageSource.bmp'));
[m,n] = size(imhote);

m_demi = m/2;
n_demi = n/2;

im_compressed = randi([0,255],m/4,n);
D1 = 


[LL,LH,HL,HH] = dwt2(imhote,'haar');
