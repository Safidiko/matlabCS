function javaCipheringLauncher(binPath,className,cipherType,input_path,output_path,ligne,colonne)
%% PARAMETERS TO CHANGE: 
    command = sprintf('java -cp %s %s %s %s %s %d %d',binPath, className,cipherType,input_path,output_path,ligne,colonne);
    [~,s] = system(command);
    disp(s)
end
