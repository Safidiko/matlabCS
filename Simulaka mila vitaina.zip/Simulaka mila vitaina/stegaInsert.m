function stegoImage =stegaInsert(coverImage, secretImage, outputImagePath)
    % Get the sizes of the images
    [coverRows, coverCols, ~] = size(coverImage);
    [secretRows, secretCols, ~] = size(secretImage);
    % Ensure the secret image can fit into the cover image
    if secretRows > coverRows || secretCols > coverCols 
        error('The secret image is too large to fit into the cover image.');
    end
    % Flatten the secret image into a single row of bits
    secretBits = de2bi(secretImage(:), 8, 'left-msb');
    secretBits = secretBits';
    secretBits = secretBits(:);
    % Embed the secret bits into the LSB of the cover image
    coverImage = coverImage(:);
    coverBits = de2bi(coverImage, 8, 'left-msb');
    coverBits(:, end) = secretBits(1:length(coverImage));
    coverBits = bi2de(coverBits, 'left-msb');
    % Reshape back to the original cover image dimensions
    stegoImage = reshape(coverBits, coverRows, coverCols);
    % Save the stego image
    
    imwrite(stegoImage, outputImagePath);
end